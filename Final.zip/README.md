# Gen Clash im OP – Flutter App

Diese App zeigt auf einfache Weise die Unterschiede zwischen Generationen im OP-Saal – Babyboomer bis Gen Z – und bietet ein interaktives Quiz zur Reflexion von Kommunikations- und Arbeitsstilen.

## Features
- Übersicht zu Babyboomer, Gen X, Y, Z
- Konfliktanalyse & Lösungsvorschläge
- Interaktives Quiz mit Feedback
- Flutter UI, mobiloptimiert

## Start
```bash
flutter pub get
flutter run
```

## Zielgruppe
Pflegekräfte, OTA/ATA-Auszubildende, Praxisanleiter*innen, Lehrkräfte

---

Made with ❤️ by Ardis Halilaj
