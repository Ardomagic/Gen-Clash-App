import 'package:flutter/material.dart';

void main() => runApp(GenClashApp());

class GenClashApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Gen Clash im OP',
      theme: ThemeData(primarySwatch: Colors.teal),
      home: HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Gen Clash im OP')),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Image.network('https://upload.wikimedia.org/wikipedia/commons/thumb/2/2e/Operating_room.jpg/640px-Operating_room.jpg'),
            SizedBox(height: 20),
            Text(
              'Brücken zwischen Erfahrung & Innovation',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 40),
            ElevatedButton(
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => IntroPage())),
              child: Text('Einleitung'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => GenerationOverviewPage())),
              child: Text('Generationenübersicht'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ConflictPage())),
              child: Text('Konflikte'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SolutionPage())),
              child: Text('Lösungen & Umgang'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => QuizPage())),
              child: Text('Quiz'),
            ),
          ],
        ),
      ),
    );
  }
}

class IntroPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) => Scaffold(body: Center(child: Text('Einleitung')));
}

class GenerationOverviewPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) => Scaffold(body: Center(child: Text('Generationenübersicht')));
}

class ConflictPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) => Scaffold(body: Center(child: Text('Konflikte')));
}

class SolutionPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) => Scaffold(body: Center(child: Text('Lösungen & Umgang')));
}

class QuizPage extends StatefulWidget {
  @override
  _QuizPageState createState() => _QuizPageState();
}

class _QuizPageState extends State<QuizPage> {
  int currentQuestion = 0;
  String? selected;
  String feedback = '';

  final List<Map<String, Object>> questions = [
    {
      'question': 'Welche Generation bevorzugt direkte und formelle Kommunikation?',
      'answers': ['Gen X', 'Millennials', 'Babyboomer', 'Gen Z'],
      'correct': 'Babyboomer'
    },
    {
      'question': 'Welche Generation ist besonders multimedial und digital geprägt?',
      'answers': ['Gen X', 'Millennials', 'Gen Z', 'Babyboomer'],
      'correct': 'Gen Z'
    },
    {
      'question': 'Was kennzeichnet Generation X?',
      'answers': ['Hierarchie', 'Feedbackkultur', 'Bindeglied', 'Unsicherheit mit Technik'],
      'correct': 'Bindeglied'
    },
    {
      'question': 'Welche Generation legt viel Wert auf Transparenz und Diversity?',
      'answers': ['Babyboomer', 'Gen X', 'Gen Z', 'Millennials'],
      'correct': 'Gen Z'
    },
    {
      'question': 'Was ist ein häufiger Konflikt im OP-Alltag?',
      'answers': ['Gleiches Alter', 'Überkommunikation', 'Unterschiedliche Kanäle', 'Keine Technik'],
      'correct': 'Unterschiedliche Kanäle'
    },
    {
      'question': 'Was hilft, Generationenkonflikte zu lösen?',
      'answers': ['Strengere Regeln', 'Mentorenprogramme', 'Technikverbot', 'Hierarchische Führung'],
      'correct': 'Mentorenprogramme'
    },
  ];

  void checkAnswer() {
    final correct = questions[currentQuestion]['correct'] as String;
    setState(() {
      if (selected == correct) {
        feedback = '✅ Richtig!';
      } else {
        feedback = '❌ Falsch. Richtige Antwort: $correct';
      }
    });
  }

  void nextQuestion() {
    setState(() {
      if (currentQuestion < questions.length - 1) {
        currentQuestion++;
        selected = null;
        feedback = '';
      } else {
        feedback = '🎉 Du hast das Quiz beendet!';
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final q = questions[currentQuestion];
    return Scaffold(
      appBar: AppBar(title: Text('Quiz')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            Text(q['question'] as String, style: TextStyle(fontSize: 18)),
            ...(q['answers'] as List<String>).map((a) => RadioListTile(
              title: Text(a),
              value: a,
              groupValue: selected,
              onChanged: (val) => setState(() => selected = val),
            )),
            ElevatedButton(onPressed: checkAnswer, child: Text('Antwort prüfen')),
            SizedBox(height: 10),
            Text(feedback, style: TextStyle(fontSize: 16)),
            if (feedback.isNotEmpty && currentQuestion < questions.length - 1)
              ElevatedButton(onPressed: nextQuestion, child: Text('Nächste Frage')),
          ],
        ),
      ),
    );
  }
}
